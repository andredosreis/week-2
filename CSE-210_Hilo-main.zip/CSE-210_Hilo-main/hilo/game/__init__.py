"""
The game package contains the classes for playing Hilo.
"""