class Deck:
    '''
    Represents the deck of cards being drawn from. 
    Can be shuffled, drawn from, or reset.
    '''
    pass